# react个人最佳实践(一)--弹窗

做了四年的React业务仔，不断地将自己的理念实践在开发中

逐渐开发出了一套自己的最佳实践，并实现为Demo代码

日常开发中反复思考完善过后，即使未推广的情况下前端同学也纷纷来“抄作业”

在目前项目中所有适用场景得到了大家的自发应用

有任何相关需求的时候，直接根据Demo生成能运行的模板文件，再根据业务填充内容

降低心智负担，提升开发速度，还能减少bug的出现概率

## 弹窗Demo源码

任何弹窗相关的需求，复制粘贴该demo即可使用

这是个人总结的一个完整弹窗逻辑的最简运行demo

主在提供一个思路方法，大家copy后可根据自己的理解修改

```ts
// ModalDemo 弹窗封装页面
import { Form, Input, Modal } from 'antd';
import React, { useImperativeHandle, useRef, useState } from 'react';

export interface ModalDemoForm {
    name: string;
}

export interface ModalDemoRefType {
    show: () => Promise<ModalDemoForm | false>;
}
interface ModalDemoPropsType {}

const ModalDemo = React.forwardRef<ModalDemoRefType, ModalDemoPropsType>((_props, ref) => {
    const [visible, setVisible] = useState(false);
    const [form] = Form.useForm();
    const promiseRef = useRef<{ resolve: (value: ModalDemoForm | false) => void }>();

    useImperativeHandle(ref, () => ({
        show: () => {
            setVisible(true);
            return new Promise((resolve) => {
                promiseRef.current = { resolve };
            });
        },
    }));

    const handleConfirm = async () => {
        setVisible(false);
        const formResult = await form.validateFields();
        promiseRef.current?.resolve(formResult);
    };
    const handleCancel = () => {
        setVisible(false);
        promiseRef.current?.resolve(false);
    };

    return (
        <Modal
            title='ModalDemo'
            open={visible}
            onOk={handleConfirm}
            onCancel={handleCancel}
        >
            <Form form={form}>
                <Form.Item label='name' name='name' required>
                    <Input maxLength={8} autoComplete='off' />
                </Form.Item>
            </Form>
        </Modal>
    );
});

export default ModalDemo;
```

## 弹窗Demo使用方式

```ts
// ModalDemoTestPage.tsx 弹窗使用示例页面
import { Button } from 'antd';
import React, { useRef } from 'react';
import ModalDemo, { ModalDemoRefType } from './ModalDemo';

const ModalDemoTestPage: React.FC = () => {
    const demoModalRef = useRef<ModalDemoRefType>(null);

    const longCheck = async () => {
        const result = await demoModalRef.current!.show();
        if (!result) {
            return;
        }
        console.log('result as ModalDemoForm', result);
    };
    return (
        <div>
            <h1>ModalDemoTestPage </h1>
            <Button onClick={longCheck}>Click Here!</Button>
            <ModalDemo ref={demoModalRef} />
        </div>
    );
};

export default ModalDemoTestPage;
```

核心代码就是这些，下面是一些碎碎念，糅合了我

带大家体会一下这种封装模式带来的 使用便利，这样更能体会其 __适用场景__

## 弹窗Demo代码思路

### 普通的弹窗封装模式的缺点

使用处 流程割裂/阅读困难/逻辑重复/产生额外的变量:

需要传入`onSuccess`/`onCancel`等函数回调,整个业务流程难以在一个函数中解决

阅读代码时，阅读到弹窗调用处，又需要从jsx代码中找其回调函数，再继续阅读

有些业务逻辑可能需要在 成功/失败时均调用，需要额外抽离逻辑以实现复用

### 弹窗应关注

有些同学在需要封装一个弹窗组件时，会仅封装`<Modal></Modal>`内的内容作为组件，

而不将`Modal`本身一同封装进去,使用者需自行包裹`Modal`，并自行控制`Modal`的开启关闭

这种封装方式，

1. 一种可能是对组件理解不够深刻，认为`<Modal></Modal>`必须出现在调用者页面

    这显然是没必要的顾虑，

2. 另一个原因是认为弹窗开启关闭应该由外部控制

其实不然，弹窗本身 以及弹窗封装者 是最清楚弹窗生命周期的人 弹窗相关的整个业务应该高度聚合在弹窗内，由弹窗组件本身控制，

甚至很多时候，调用了弹窗组件，弹窗都不一定会开启，例如 传入的数据校验报错，直接tip提醒而非打开弹窗

应该做到 【使用者仅需关注 调用时传入的数据 及获得 成功/失败时获得的结果 就行】

需要 TS支持 以及 对业务的彻底思考，让弹窗足够黑盒

### 封装理念总结

好，看到这里，让我们来总结几个弹窗封装的关键思想

__组件本身业务高内聚__

其实不仅仅是弹窗，所有组件封装都可以用到这些思路，至少我是这么想的

## 各类使用场景举例及注意事项

大概涉及了 Modal Table Form 以及 Table+Form 四个业务场景
