export default {
    extends: ['airbnb', 'airbnb/hooks'],
    env: {
        es6: true,
    }
}