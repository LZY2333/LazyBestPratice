import { Form, Input, Modal } from 'antd';
import React, { useImperativeHandle, useRef, useState } from 'react';

export interface ModalDemoForm {
    name: string;
}

export interface ModalDemoRefType {
    show: () => Promise<ModalDemoForm | false>;
}
interface ModalDemoPropsType {}

// 一
// React.forwardRef, 泛型第一个参数为 ref的类型约束，这里有两大优点
// 1. 约束内部对ref挂载的函数，同时编码时能获取智能提示
// 2. export ref的类型，约束外部对该ref的使用，同时编码时获取智能提示
// 暴露类型约束能极大降低出错概率，智能提示也让组件更加黑盒，使用简便，使用者无需阅读内部代码逻辑

// 二 需要
// 这个问题，提现在类型约束上，就是说，我该修改 PropsType 还是 RefType
// 直接说结论: 当组件状态 与 组件摆放所处位置相关时，应设置为 props属性
// 当

// 三 show函数可直接返回一个resolve 或reject 的Promise，例如 校验成功 / 校验失败
// 记住一句话，对于page来说 用户在弹窗界面的操作视为异步视为一个Promise，

// 弹窗的开启关闭
const ModalDemo = React.forwardRef<ModalDemoRefType, ModalDemoPropsType>((_props, ref) => {
    const [visible, setVisible] = useState(false);
    const [form] = Form.useForm();
    // 弹窗核心逻辑
    const promiseRef = useRef<{ resolve: (value: ModalDemoForm | false) => void }>();

    useImperativeHandle(ref, () => ({
        show: () => {
            // 获取到数据可以做一些 与该弹窗业务逻辑相关的预先校验
            // 或对 数据进行处理 根据数据修改弹窗状态 等


            setVisible(true);
            return new Promise((resolve) => {
                promiseRef.current = { resolve };
            });
        },
    }));

    const handleConfirm = async () => {
        setVisible(false);
        const formResult = await form.validateFields();
        promiseRef.current?.resolve(formResult);
    };
    const handleCancel = () => {
        setVisible(false);
        promiseRef.current?.resolve(false);
    };

    return (
        <Modal
            title='ModalDemo'
            open={visible}
            onOk={handleConfirm}
            onCancel={handleCancel}
        >
            <Form form={form}>
                <Form.Item label='name' name='name' required>
                    <Input maxLength={8} autoComplete='off' />
                </Form.Item>
            </Form>
        </Modal>
    );
});

export default ModalDemo;
